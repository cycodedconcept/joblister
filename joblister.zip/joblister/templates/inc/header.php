<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>JobLister</title>
    
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="fontawesome/css/all.css">

</head>
<body>
<div class="container">
<div class="header clearfix">
<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
<a class="navbar-brand text-success font-weight-bold" href="#">JobLister</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarsExampleDefault">
  <div class="container">
  <ul class="navbar-nav ml-auto">
    <li class="nav-item active">
        <a class="nav-link text-success font-weight-bold" href="index.php"><i class="fa fa-home" style="color: red; margin-right: 2px;">Home</i></a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-success font-weight-bold" href="create.php">Creating Listing</a>
      </li>
    </ul>
  </div>
  </div>
</nav>
<h4 class="text-muted"><?php echo SITE_TITLE; ?></h4>
</div>
<?php displayMessage(); ?>
