<?php include 'inc/header.php'; ?>
  <h4 class="page-header">Create Job Listing</h4>
  <form method="post" action="create.php">
    <div class="form-component input-medium">
        <label>Company</label>
        <div class="input-group-prepend">
            <div class="input-group-text" style="background-color: red; border-radius: 2px;"><i class="fa fa-building" aria-hidden="true"  style="color: #222;"></i></div>
            <input type="text" class="form-control" name="company">
        </div>
    </div>
    <br>
    <div class="form-component input-medium">
        <label>Category</label>
        <div class="input-group-prepend">
        <div class="input-group-text" style="background-color: red; border-radius: 2px;"><i class="fa fa-list-alt" aria-hidden="true"  style="color: #222;"></i></div>
        <select class="form-control" name="category">
        <option value="0">Chose category</option>
          <?php foreach($categories as $category): ?>
             <option value="<?php echo $category->id; ?>"><?php echo $category->name; ?></option>
          <?php endforeach; ?>
        </select>
        </div>
    </div>
    <br>
    <div class="form-component input-medium">
        <label>Job Title</label>
        <div class="input-group-prepend">
        <div class="input-group-text" style="background-color: red; border-radius: 2px;"><i class="fa fa-briefcase" aria-hidden="true"  style="color: #222;"></i></div>
           <input type="text" class="form-control" name="job_title">
        </div>
    </div>
    <br>
    <div class="form-component input-medium">
        <label>Description</label>
        <div class="input-group-prepend">
        <div class="input-group-text" style="background-color: red; border-radius: 2px;"><i class="fa fa-audio-description" aria-hidden="true"  style="color: #222;"></i></div>
        <textarea class="form-control" name="description"></textarea>
        </div>
    </div>
    <br>
    <div class="form-component input-medium">
        <label>Location</label>
        <div class="input-group-prepend">
        <div class="input-group-text" style="background-color: red; border-radius: 2px;"><i class="fa fa-map-marker-alt" aria-hidden="true"  style="color: #222;"></i></div>
        <input type="text" class="form-control" name="location">
        </div>
    </div>
    <br>
    <div class="form-component input-medium">
        <label>Salary</label>
        <div class="input-group-prepend">
        <div class="input-group-text" style="background-color: red; border-radius: 2px;"><i class="fa fa-wallet" aria-hidden="true"  style="color: #222;"></i></div>
        <input type="text" class="form-control" name="salary">
        </div>
    </div>
    <br>
    <div class="form-component input-medium">
        <label>Contact User</label>
        <div class="input-group-prepend">
        <div class="input-group-text" style="background-color: red; border-radius: 2px;"><i class="fa fa-user-alt" aria-hidden="true"  style="color: #222;"></i></div>
        <input type="text" class="form-control" name="contact_user">
        </div>
    </div>
    <br>
    <div class="form-component input-medium">
        <label>Contact Email</label>
        <div class="input-group-prepend">
        <div class="input-group-text" style="background-color: red; border-radius: 2px;"><i class="fa fa-envelope" aria-hidden="true" style="color: #222;"></i></div>
        <input type="text" class="form-control" name="contact_email">
        </div>
    </div>
    <br>
    <button type="submit" class="btn btn-danger" value="submit" name="submit">
        <i class="fa fa-arrow-circle-right fa-lg"></i> submit
    </button>    
    <!--<input type="submit" class="btn btn-danger" value="submit" name="submit">-->
  </form>
  <br><br>
<?php include 'inc/footer.php'; ?>